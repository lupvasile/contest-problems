package org.jfugue.pattern;

import java.util.List;

public interface TokenProducer {
    public List<Token> getTokens();
}
